from django.apps import AppConfig


class SchrinerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'schriner'
